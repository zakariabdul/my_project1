import React from "react";

class Weather extends React.Component{
  render(){
    return(
      <div>Weather component</div>
    );
  }
};
export default Weather;
